from flask import Flask, render_template, flash, url_for, request

app = Flask(__name__)
app.config['SECRET_KEY'] = 'dsfodjshfudskfjldshkgqfkjdslfhdsjlfdshjfdsjk!!!'
colors = ["Red", "Pink", "Orange", "Yellow", "Plum", "Indigo", "Purple", "Peru", "Gray", "Blue", "Lime"]


@app.route('/')
@app.route('/index')
def index():
    print(url_for('index'))
    return render_template('base.html', colors=colors)


@app.route('/questionnaire', methods=['POST', 'GET'])
def questionnaire():
    print(url_for('questionnaire'))
    if request.method == 'POST':
        if len(request.form) == 7:
            flash('Форма успешно отправлена')
        print(request.form)
    return render_template('questionnaire.html')


if __name__ == '__main__':
    app.run(debug=True)
